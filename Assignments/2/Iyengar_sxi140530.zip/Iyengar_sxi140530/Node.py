__author__ = 'srikant'

# 1 is the left branch and 0 is the right branch
class Node:
    'Node class of tree'
    def __init__(self):
        self.data = []
        self.left = None
        self.right = None
        self.attribute = None



