Name : Srikant Iyengar
Net ID: sxi140530

******************************************************************************************************************************************
The Folder Part2 contains code for the 2nd part of the assignment. 

Contents:

1) tweets-k-means.py   -->  Python script for the k-means program.
2) Tweet.py     -->  Tweet class file for storing each tweet
3) Output.txt --> Output files for the 5 runs associated with the assignment.

*******************************************************************************************************************************************

SSE values for 5 runs:

k-value			SSE value
  25			28.0526111567

********************************************************************************************************************************************

Command to execute the file:

./tweets-k-means.py 25 "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part2/InitialSeeds.txt" "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part2/Tweets.json" "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part2/Output.txt"

*********************************************************************************************************************************************

