Name : Srikant Iyengar
Net ID: sxi140530


******************************************************************************************************************************************
The Folder Part1 contains code for the 1st part of the assignment. 

Contents:

1) k-means.py   -->  Python script for the k-means program.
2) Point.py     -->  Point class file for k-means program.
3) Output files  --> Output files for the 5 runs associated with the assignment.

*******************************************************************************************************************************************

SSE values for 5 runs:

k-value			SSE value
  10			0.770435012302
  13			0.56975343269
  14			0.52018357381
  15			0.57777970098
  17			0.387257263095

*******************************************************************************************************************************************

Command to execute the file:

./k-means.py 17 "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/test_data.txt" "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/k-17-Output.txt"

./k-means.py 15 "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/test_data.txt" "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/k-15-Output.txt"

./k-means.py 13 "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/test_data.txt" "/home/ajaysrrinivas/Desktop/ML_Assignment_4/Iyengar_sxi140530/Part1/k-13-Output.txt"

********************************************************************************************************************************************
