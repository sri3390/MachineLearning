Name: Srikant Iyengar
Net ID: sxi140530

********************************************************************************************************************************************************************

Contents:

Report: Contains all Observations for Part 1. Also contains the tables and required results.

Hierarchical(afterPCA)k=2 : The ouptput file for Hierarchical Clustering after PCA with k=2.

Hierarchicalk=3 : The ouptput file for Hierarchical Clustering with k=3.

Kmeans(afterPCA)k=3 : The ouptput file for Kmeans Clustering after PCA with k=3.

Kmeansk=2 : The ouptput file for Kmeans Clustering with k=2.

baggingModel : Model file for Classificattion with Bagging.

Part2 : PDF file with scanned results of the Part2 of assignment.

