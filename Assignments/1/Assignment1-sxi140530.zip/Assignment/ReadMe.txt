The Program is written in Python. The Output file will be created in the same directory where the Python script file is placed. 

In a linux machine Install python using wither pip or any other tool.
ref doc: http://docs.python-guide.org/en/latest/starting/install/linux/

For a mac machine:
https://www.python.org/downloads/mac-osx/

For Windows based Systems:
https://www.python.org/downloads/windows/

Run python Assignment1.py to run the python script. You will find an output text file called "Output.txt" that contains the desired output.

-------------------------------------------------------------------------------------------------------------------------------------------

According to me the best strategy amoung the three strategies would be the First Stategy. The amount waged remains independent of the status of the last bet and hence is much safer strategy. The person has atleast 10 chances to play the game unlike the other two stratergies, hence plenty of oppurtunities to gain back his lost money.


